package com.example.mbanking;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private HistoryAdapter adapter;
    private List<Transaction> transactionList;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history_layout); // Use the correct layout

        // Set up the toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Transaction History");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recycler_view); // Make sure this ID exists in history_layout.xml
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize transaction list and add dummy data
        transactionList = new ArrayList<>();
        transactionList.add(new Transaction("Transfer to Budi", "IDR 500,000", "2024-07-29 12:34"));
        transactionList.add(new Transaction("Transfer to Virtual Account", "IDR 1,000,000", "2024-07-28 15:45"));
        transactionList.add(new Transaction("Transfer to Andre", "IDR 250,000", "2024-08-01 09:15"));
        transactionList.add(new Transaction("Transfer to Setiawan", "IDR 22,000", "2024-08-02 11:00"));
        transactionList.add(new Transaction("Transfer to Bunga Mekar Pontianak", "IDR 100,000", "2024-08-03 14:20"));
        // Add more dummy data as needed

        // Initialize adapter and set it to RecyclerView
        adapter = new HistoryAdapter(transactionList);
        recyclerView.setAdapter(adapter);
    }
}
