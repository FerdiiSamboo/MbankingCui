package com.example.mbanking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {
    private TextView balanceText;
    private TextView balanceUSDText;
    private TextView balanceEURText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_layout);

        balanceText = findViewById(R.id.tv_balance);
        balanceUSDText = findViewById(R.id.tv_balance_usd);
        balanceEURText = findViewById(R.id.tv_balance_eur);

        double userBalance = 10000000;

        balanceText.setText(String.format("IDR %.2f", userBalance));

        double exchangeRateUSD = 0.000069;
        double exchangeRateEUR = 0.000061;

        double balanceUSD = userBalance * exchangeRateUSD;
        double balanceEUR = userBalance * exchangeRateEUR;

        balanceUSDText.setText(String.format("$ %.2f", balanceUSD));
        balanceEURText.setText(String.format("€ %.2f", balanceEUR));

        Button btnTransfer = findViewById(R.id.btn_transfer);
        Button btnVirtualAccountTransfer = findViewById(R.id.btn_virtual_account_transfer);
        Button btnHistory = findViewById(R.id.btn_history);
        Button btnLogout = findViewById(R.id.btn_logout);

        btnTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, TransferActivity.class);
                intent.putExtra("balance", userBalance);
                startActivity(intent);
            }
        });

        btnVirtualAccountTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, VirtualAccountTransferActivity.class);
                intent.putExtra("balance", userBalance);
                startActivity(intent);
            }
        });

        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MenuActivity.this, "Riwayat Transaksi diklik!", Toast.LENGTH_SHORT).show();
                // Start HistoryActivity
                Intent intent = new Intent(MenuActivity.this, HistoryActivity.class);
                startActivity(intent);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement logout logic
                Toast.makeText(MenuActivity.this, "Logout diklik!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
