package com.example.mbanking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TransferActivity extends AppCompatActivity {
    private EditText etRecipientAccount;
    private EditText etTransferAmount;
    private Button btnTransfer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.transfer_layout);

        // Initialize views
        etRecipientAccount = findViewById(R.id.et_recipient_account);
        etTransferAmount = findViewById(R.id.et_transfer_amount);
        btnTransfer = findViewById(R.id.btn_transfer);

        btnTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String recipientAccount = etRecipientAccount.getText().toString();
                String transferAmountStr = etTransferAmount.getText().toString();

                if (TextUtils.isEmpty(recipientAccount) || TextUtils.isEmpty(transferAmountStr)) {
                    Toast.makeText(TransferActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                double transferAmount = Double.parseDouble(transferAmountStr);

                // Start the TransferConfirmationActivity
                Intent intent = new Intent(TransferActivity.this, TransferConfirmationActivity.class);
                intent.putExtra("transferAmount", transferAmount);
                startActivity(intent);
            }
        });
    }
}