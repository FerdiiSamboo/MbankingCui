package com.example.mbanking;

public class Transaction {
    private final String description;
    private final String amount;
    private final String date;

    public Transaction(String description, String amount, String date) {
        this.description = description;
        this.amount = amount;
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public String getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }
}
