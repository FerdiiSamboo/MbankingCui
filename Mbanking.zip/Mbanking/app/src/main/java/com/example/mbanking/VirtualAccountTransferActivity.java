package com.example.mbanking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class VirtualAccountTransferActivity extends AppCompatActivity {
    private TextView tvBalance;
    private EditText etVirtualAccountNumber;
    private EditText etTransferAmount;
    private Button btnTransfer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.virtual_account_transfer_layout);

        tvBalance = findViewById(R.id.tv_balance_idr);
        etVirtualAccountNumber = findViewById(R.id.et_virtual_account_number);
        etTransferAmount = findViewById(R.id.et_transfer_amount);
        btnTransfer = findViewById(R.id.btn_transfer);

        // Get the user's balance from the intent extra
        Intent intent = getIntent();
        double userBalance = intent.getDoubleExtra("balance", 0);

        tvBalance.setText(String.format("IDR %.2f", userBalance));

        btnTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the virtual account number and transfer amount
                String virtualAccountNumber = etVirtualAccountNumber.getText().toString();
                double transferAmount = Double.parseDouble(etTransferAmount.getText().toString());

                // Check if the transfer amount is valid
                if (transferAmount <= 0) {
                    Toast.makeText(VirtualAccountTransferActivity.this, "Invalid transfer amount", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if the user has sufficient balance
                if (transferAmount > userBalance) {
                    Toast.makeText(VirtualAccountTransferActivity.this, "Insufficient balance", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Start the VirtualAccountTransferConfirmationActivity
                Intent intent = new Intent(VirtualAccountTransferActivity.this, VirtualAccountTransferConfirmationActivity.class);
                intent.putExtra("virtual_account_number", virtualAccountNumber);
                intent.putExtra("transfer_amount", transferAmount);
                startActivity(intent);
            }
        });
    }
}