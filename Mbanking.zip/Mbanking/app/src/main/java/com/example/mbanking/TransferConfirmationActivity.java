package com.example.mbanking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class TransferConfirmationActivity extends AppCompatActivity {
    private TextView tvTransferAmountIDR;
    private TextView tvTransferAmountUSD;
    private TextView tvTransferAmountEUR;
    private TextView tvTransferNumber;
    private Button btnDone;
    private Button btnBackToMenu; // added

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.transfer_confirmation_layout);

        // Initialize views
        tvTransferAmountIDR = findViewById(R.id.tv_transfer_amount_idr);
        tvTransferAmountUSD = findViewById(R.id.tv_transfer_amount_usd);
        tvTransferAmountEUR = findViewById(R.id.tv_transfer_amount_eur);
        tvTransferNumber = findViewById(R.id.tv_transfer_number);
        btnDone = findViewById(R.id.btn_done);
        btnBackToMenu = findViewById(R.id.btn_back_to_menu); // added

        // Get the transfer amount from the intent
        Intent intent = getIntent();
        double transferAmount = intent.getDoubleExtra("transferAmount", 0.0);

        // Generate a random transfer number
        String transferNumber = generateTransferNumber();

        // Display the transfer confirmation details
        tvTransferAmountIDR.setText(String.format("IDR %.2f", transferAmount));
        tvTransferAmountUSD.setText(String.format("$ %.2f", transferAmount / 14000));
        tvTransferAmountEUR.setText(String.format("€ %.2f", transferAmount / 17000));
        tvTransferNumber.setText("Transfer Number: " + transferNumber);

        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnBackToMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the menu activity
                Intent intent = new Intent(TransferConfirmationActivity.this, MenuActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private String generateTransferNumber() {
        Random random = new Random();
        int transferNumber = random.nextInt(1000000) + 1;
        return String.format("TRF-%06d", transferNumber);
    }
}