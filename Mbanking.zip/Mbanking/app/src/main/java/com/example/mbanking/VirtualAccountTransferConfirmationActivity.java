package com.example.mbanking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class VirtualAccountTransferConfirmationActivity extends AppCompatActivity {
    private TextView tvVirtualAccountNumber;
    private TextView tvTransferAmount;
    private Button btnConfirmTransfer;
    private TextView tvTransferAmountIDR;
    private TextView tvTransferAmountEuro;
    private TextView tvTransferAmountUSD;
    private TextView tvTransferNumber;
    private TextView tvTransactionTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.virtual_account_transfer_confirmation);

        tvVirtualAccountNumber = findViewById(R.id.tv_virtual_account_number);
        tvTransferAmount = findViewById(R.id.tv_transfer_amount);
        btnConfirmTransfer = findViewById(R.id.btn_confirm_transfer);
        tvTransferAmountIDR = findViewById(R.id.tv_transfer_amount_idr);
        tvTransferAmountEuro = findViewById(R.id.tv_transfer_amount_euro);
        tvTransferAmountUSD = findViewById(R.id.tv_transfer_amount_usd);
        tvTransferNumber = findViewById(R.id.tv_transfer_number);
        tvTransactionTime = findViewById(R.id.tv_transaction_time);

        // Get the virtual account number and transfer amount from the intent extra
        Intent intent = getIntent();
        String virtualAccountNumber = intent.getStringExtra("virtual_account_number");
        double transferAmount = intent.getDoubleExtra("transfer_amount", 0);

        tvVirtualAccountNumber.setText("Virtual Account Number: " + virtualAccountNumber);
        tvTransferAmount.setText("Transfer Amount: IDR " + String.format("%.2f", transferAmount));

        btnConfirmTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Generate a random transfer number
                String transferNumber = generateTransferNumber();

                // Set the transfer amount and currency
                tvTransferAmountIDR.setText("IDR " + String.format("%.2f", transferAmount));
                tvTransferAmountEuro.setText("EUR " + String.format("%.2f", transferAmount / 14000));
                tvTransferAmountUSD.setText("USD " + String.format("%.2f", transferAmount / 14000 * 0.85));

                // Set the transfer number and transaction time
                tvTransferNumber.setText("Transfer Number: " + transferNumber);
                tvTransactionTime.setText("Transaction Time: " + getCurrentTime());

                // Show a toast message
                Toast.makeText(VirtualAccountTransferConfirmationActivity.this, "Transfer confirmed!", Toast.LENGTH_SHORT).show();

                // Finish the activity
                finish();
            }
        });
    }

    private String generateTransferNumber() {
        Random random = new Random();
        return "TRF-" + String.format("%08d", random.nextInt(10000000));
    }

    private String getCurrentTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return dateFormat.format(new Date());
    }
}